#include "fufuThemeListController.h"
#import <UIKit/UIKit.h>

@implementation fufuThemeListController

- (NSArray *)specifiers {
	if (!_specifiers) {
		_specifiers = [self loadSpecifiersFromPlistName:@"ThemeList" target:self];
	}

	return _specifiers;
}

@end
